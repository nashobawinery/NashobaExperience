# Training LMS System Export

This folder contains all the code needed to implement the Training LMS (Learning Management System) in your application.

## Overview

The LMS system provides:
- **Course Management**: Create and manage training courses with lessons, content blocks, and quizzes
- **Staff Assignments**: Assign courses to staff members with due dates and progress tracking
- **Content Delivery**: Rich content blocks (text, video, images, files, embeds)
- **Quiz System**: Multiple question types, scoring, and attempts tracking
- **Certificates & Badges**: Automatic certificate generation and achievement badges
- **Public Training Portal**: Staff can access training via 4-digit codes without full system login
- **Department Targeting**: Courses can target specific departments
- **Compliance Tracking**: Renewal frequencies, regulatory references, and expiration tracking

## Files Included

### Database Schema (`schema_lms.ts`)
All database tables needed for the LMS system:
- `staffCourses` - Course catalog
- `staffCourseAssignments` - Track staff course assignments
- `courseLessons` - Lessons within courses
- `lessonPages` - Pages within lessons
- `lessonContentBlocks` - Content blocks (text, video, images, etc.)
- `coursePrerequisites` - Learning path dependencies
- `questionBanks` - Reusable question pools
- `questions` - Quiz questions
- `quizzes` - Course/lesson quizzes
- `quizQuestions` - Links questions to quizzes
- `quizAttempts` - Staff quiz attempts
- `questionResponses` - Individual answers
- `lessonProgress` - Lesson completion tracking
- `certificates` - Completion certificates
- `badges` - Achievement badges
- `staffBadges` - Earned badges
- `courseRatings` - Staff feedback on courses
- `courseDepartments` - Department targeting
- `trainingPortalSessions` - Public portal access sessions

### API Routes (`routes_lms.ts`)
All backend API endpoints for:
- Course CRUD operations
- Assignment management
- Lesson and content management
- Quiz management and grading
- Progress tracking
- Certificate generation
- Badge awarding
- Public training portal authentication

### Storage Methods (`storage_lms.ts`)
Database operations for all LMS tables.

### Frontend Components

#### `TrainingLMS.tsx` (Main Admin Page)
Full-featured admin interface for managing:
- Course catalog with categories
- Course content builder (lessons, pages, content blocks)
- Quiz builder with multiple question types
- Staff assignments and progress tracking
- Department targeting
- Certificates and badges
- Course ratings and analytics

#### `TrainingPortal.tsx` (Public Staff Portal)
Simplified training portal for staff members:
- 4-digit code authentication
- Course viewing and progress
- Lesson navigation
- Quiz taking
- Certificate viewing

#### `TrainingPortalSettingsDialog.tsx`
Settings dialog for configuring the training portal.

## Installation Steps

### 1. Add Database Schema

Copy the contents of `schema_lms.ts` to your `shared/schema.ts` file.

**Prerequisites**: Your schema needs these existing tables:
- `facilities` - Facility/organization table
- `staff` - Staff members table

### 2. Run Database Migration

```bash
npm run db:push
```

### 3. Add Storage Methods

Add the contents of `storage_lms.ts` to your `server/storage.ts` file.

### 4. Add API Routes

Add the contents of `routes_lms.ts` to your `server/routes.ts` file.

### 5. Add Frontend Pages

1. Copy `TrainingLMS.tsx` to `client/src/pages/TrainingLMS.tsx`
2. Copy `TrainingPortal.tsx` to `client/src/pages/TrainingPortal.tsx`
3. Copy `TrainingPortalSettingsDialog.tsx` to `client/src/components/TrainingPortalSettingsDialog.tsx`

### 6. Add Routes in App.tsx

```tsx
import TrainingLMS from "@/pages/TrainingLMS";
import TrainingPortal from "@/pages/TrainingPortal";

// In your Router:
<Route path="/training" component={TrainingLMS} />
<Route path="/training-portal" component={TrainingPortal} />
```

### 7. Required Dependencies

Make sure you have these packages installed:
- `@tanstack/react-query`
- `react-hook-form`
- `@hookform/resolvers`
- `zod`
- `lucide-react`
- `date-fns`
- Shadcn UI components (Card, Button, Dialog, etc.)

## Configuration

### Staff Training Portal Access

Staff members can access the training portal using a 4-digit access code. To enable:

1. Go to Staff settings
2. Set up a 4-digit training portal access code
3. Staff can then access `/training-portal` and log in with their last name + code

### Course Categories

Default categories include:
- Clinical
- Safety  
- Compliance
- Orientation
- Skills
- Regulatory

### Question Types

Supported quiz question types:
- Multiple Choice (single answer)
- Multiple Select (multiple correct answers)
- True/False
- Short Answer
- Matching

## Key Features

### Course Content Builder
- Drag-and-drop lesson ordering
- Rich content blocks with text, video, images, files
- Page-based lesson structure (1.1, 1.2, etc.)
- Visual content preview

### Quiz System
- Question banks for reusable questions
- Random question selection
- Time limits and attempt limits
- Automatic and manual grading
- Score tracking and pass/fail

### Progress Tracking
- Assignment status (assigned, in_progress, completed)
- Lesson-level progress
- Quiz attempts and scores
- Time spent tracking

### Certificates
- Automatic generation on course completion
- Unique certificate numbers
- Expiration dates for renewal courses
- PDF generation support

### Badges
- Achievement-based awards
- Course completion badges
- Score-based badges
- Bronze/Silver/Gold/Platinum tiers

## Notes

- The export is designed to be modular - you can implement just the core features first
- Object storage integration is needed for file/image uploads (uses Replit Object Storage)
- Email integration is optional (for training assignments and reminders)
- The public training portal requires session management

## Support

This LMS system is part of a larger assisted living facility management system. Some features may reference other modules (like facility departments) that you may need to adapt for your use case.
